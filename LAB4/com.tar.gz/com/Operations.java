// Interface
package Student;

interface Operations{
	abstract void register(Student std);
	abstract void logIn(String id, String password);
	abstract void exit();
}


